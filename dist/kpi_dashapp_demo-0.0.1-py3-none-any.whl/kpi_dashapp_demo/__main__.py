from kpi_dashapp_demo.app import app


if __name__ == '__main__':
    app.run_server(port=8040, debug=False)









