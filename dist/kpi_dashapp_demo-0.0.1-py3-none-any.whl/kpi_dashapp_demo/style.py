cardimg_style = {'width': '100%', 'height': '100%',
              "opacity": 0.9, "objectFit": "cover"
              }
cardbody_style = {"margin": "2%"}

cardstyling = {"maxWidth": 195,
               "backgroundColor": "#00624e",
            }

card_style = {"width": "20rem", "height": "20rem"}

card_icon = {
    "color": "#0088BC",
    "textAlign": "center",
    "fontSize": "4em",
    "margin": "auto"
}

homepage_icon_style = {
                        "opacity": 0.9,
                        "objectFit": "cover",
                        "height": "100%",
                        "width": "100%",
                        }

page_style = {"backgroundColor": "#00624e"}

button_style = {"backgroundColor": "#fff000"}


