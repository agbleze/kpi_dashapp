from setuptools import setup

setup(name='kpi_dashapp_demo',
      version='0.0.1',
      packages=['kpi_dashapp_demo'],
      zip_safe=False,
      license='MIT',
      author='Agbleze Linus',
      description='This package is a dash application for visualization KPIs'
      )